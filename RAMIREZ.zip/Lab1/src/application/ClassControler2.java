package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.UfoFigth;

public class ClassControler2 {
	
	@FXML
	private Label label1;
	private UfoFigth uf;
	private static int[][] matrix = new int[ClassControler1.getRows()][ClassControler1.getColumns()];;
	
	public void generateMatrix(ActionEvent ae) {
		uf = new UfoFigth();
		uf.initializeRows(ClassControler1.getRows());
		uf.initializeColumns(ClassControler1.getColumns());
		uf.initializeUfoUbication();
		label1.setText(uf.fillUfoUbication());		
	}
	
	public static int[][] getMatrix() {
		return matrix;
	}

	public  void setMatrix(int[][] matrix) {
		ClassControler2.matrix = matrix;
	}

	public void nextScene(ActionEvent next) {
		try { 
    		FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(getClass().getResource("/application/Window3.fxml"));
    		Parent root =  (Parent) loader.load();
    		Scene scene = new Scene(root);
    		Stage stage = (Stage) ((Node) next.getSource()).getScene().getWindow();
    		stage.setScene(scene);
    		stage.centerOnScreen();
    		stage.show();
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
		
	}
}


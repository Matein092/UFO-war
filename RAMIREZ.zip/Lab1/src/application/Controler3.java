package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.UfoFigth;

public class Controler3 {
	
	private UfoFigth uf;
	@FXML
    private Label label1;

    @FXML
    private Label label2;
    
    @FXML
    private Label label3;

  
    public void show(ActionEvent actionEvent) {
    	uf = new UfoFigth();
    	uf.initializeRows(ClassControler1.getRows());
		uf.initializeColumns(ClassControler1.getColumns());
		uf.initializeUfoUbication();
		uf.initializeCoeficients();
		label1.setText(uf.fillUfoUbication());
		label2.setText(uf.fillCoeficients());
    }
    
    public void multiplication(ActionEvent event) {
    	uf = new UfoFigth();
    	uf.initializeRows(ClassControler1.getRows());
		uf.initializeColumns(ClassControler1.getColumns());
		uf.initializeUfoUbication();
		uf.initializeCoeficients();
		label1.setText(uf.fillUfoUbication());
		label2.setText(uf.fillCoeficients());
		label3.setText(uf.matrizMultiplication());
    	
    }
    public void nextStage(ActionEvent next) {
    	try { 
        	FXMLLoader loader = new FXMLLoader();
        	loader.setLocation(getClass().getResource("/application/Window4.fxml"));
        	Parent root =  (Parent) loader.load();
        	Scene scene = new Scene(root);
        	Stage stage = (Stage) ((Node) next.getSource()).getScene().getWindow();
        	stage.setScene(scene);
        	stage.centerOnScreen();
        	stage.show();
        } catch(Exception e) {
        	e.printStackTrace();
        }		
    }
    
}

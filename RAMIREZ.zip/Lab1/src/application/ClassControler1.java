package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ClassControler1 {
	
	@FXML
    private TextField txtR;

    @FXML
    private TextField txtC;
    
    private static int rows;
    private static int columns;

    public void nextScene(ActionEvent next) {
    	rows = Integer.parseInt(txtR.getText());
    	columns = Integer.parseInt(txtC.getText());
    	
    	try { 
    		FXMLLoader loader = new FXMLLoader();
    		loader.setLocation(getClass().getResource("/application/Window2.fxml"));
    		Parent root =  (Parent) loader.load();
    		Scene scene = new Scene(root);
    		Stage stage = (Stage) ((Node) next.getSource()).getScene().getWindow();
    		stage.setScene(scene);
    		stage.centerOnScreen();
    		stage.show();
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public static int getRows() {
    	return rows;
    }
    
    public static int getColumns() {
    	return columns;
    }
}

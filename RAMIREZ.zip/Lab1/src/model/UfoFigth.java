package model;

import java.util.Random;

public class UfoFigth {

		private int columns;
		private int rows;
		private int[][] ufoUbication;
		private int[][] coeficients;
		
		
		public UfoFigth() {
			initializeColumns(0);
			initializeRows(0);
			initializeUfoUbication();
			initializeCoeficients();
		}
		
		public void initializeColumns(int c) {
			setColumns(c);
		}
		
		public int getColumns() {
			return columns;
		}

		public void setColumns(int columns) {
			this.columns = columns;
		}

		public int getRows() {
			return rows;
		}

		public void setRows(int rows) {
			this.rows = rows;
		}

		public int[][] getUfoUbication() {
			return ufoUbication;
		}

		public void setUfoUbication(int[][] ufoUbication) {
			this.ufoUbication = ufoUbication;
		}

		public void initializeRows(int r) {
			setRows(r);
		}
		
		public void initializeUfoUbication() {
			ufoUbication = new int[rows][columns];
			for(int i = 0; i < ufoUbication.length; i++) {
				for(int j = 0; j < ufoUbication[0].length; j++) {
					ufoUbication[i][j] = 0;
				}
			}
		}
		
		public String fillUfoUbication() {
			String msg = "";
			for(int i = 0; i < ufoUbication.length; i++) {
				for(int j = 0; j < ufoUbication[0].length; j++) {
					Random r = new Random();         
                    ufoUbication[i][j] = r.nextInt(100+1);
				}
			}
			for(int i = 0; i < ufoUbication.length; i++) {
				for(int j = 0; j < ufoUbication[0].length; j++) {
					msg += ufoUbication[i][j] + "\t";					
				}
				msg += "\n";
			}
			return msg;
		}
		
		
		public String matrizMultiplication(){
			String msg = "";
			int[][] result = new int[columns][rows];
			for(int i = 0; i < ufoUbication.length; i++) {
				for(int j = 0; j < ufoUbication[0].length; j++ ) {
					result[j][i] += ufoUbication[i][j] * coeficients[j][i]; 
					msg += result[i][j] +"\t";
				}
				msg += "\n";
			}
			return msg;
			
		}
		
		public void initializeCoeficients() {
			coeficients = new int[columns][rows];
			for(int i = 0; i < coeficients.length; i++) {
				for(int j = 0; j < coeficients[0].length; j++) {
					coeficients[i][j] = 0;
				}
			}			
		}
		
		public String fillCoeficients() {
			String msg = "";
			for(int i = 0; i < coeficients.length; i++) {
				for(int j = 0; j < coeficients[0].length; j++) {
					Random r = new Random();         
					coeficients[i][j] = r.nextInt(3+1);
				}
			}
			for(int i = 0; i < coeficients.length; i++) {
				for(int j = 0; j < coeficients[0].length; j++) {
					msg += coeficients[i][j] + "\t";					
				}
				msg += "\n";
			}
			return msg;
		}
		
}
		
		
	
